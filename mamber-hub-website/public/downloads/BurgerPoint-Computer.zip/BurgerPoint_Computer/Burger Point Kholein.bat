@echo off
rem Burger Point - Qamar Sons
set "F=%~dp0BurgerPoint.html"
set "C1=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "C2=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
set "C3=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%C1%" ( start "" "%C1%" --app="file:///%F%" --start-maximized & goto :eof )
if exist "%C2%" ( start "" "%C2%" --app="file:///%F%" --start-maximized & goto :eof )
if exist "%C3%" ( start "" "%C3%" --app="file:///%F%" --start-maximized & goto :eof )
start "" msedge --app="file:///%F%" --start-maximized
